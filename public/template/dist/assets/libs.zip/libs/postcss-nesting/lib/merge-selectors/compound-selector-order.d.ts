import type { Container, Node } from 'postcss-selector-parser';
export declare function sortCompoundSelectorsInsideComplexSelector(node: Container<string, Node>): void;
