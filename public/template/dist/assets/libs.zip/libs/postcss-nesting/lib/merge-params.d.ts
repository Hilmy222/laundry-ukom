export default function mergeParams(fromParams: string, toParams: string): string;
