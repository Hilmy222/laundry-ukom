
import DataTable from 'datatables.net-autofill';

export default DataTable;
export * from 'datatables.net-autofill';
