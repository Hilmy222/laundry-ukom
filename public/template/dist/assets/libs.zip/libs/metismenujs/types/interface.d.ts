export interface IMMOptions {
    toggle?: boolean;
    triggerElement?: string;
    parentTrigger?: string;
    subMenu?: string;
}
//# sourceMappingURL=interface.d.ts.map