
import DataTable from 'datatables.net-select';

export default DataTable;
export * from 'datatables.net-select';
