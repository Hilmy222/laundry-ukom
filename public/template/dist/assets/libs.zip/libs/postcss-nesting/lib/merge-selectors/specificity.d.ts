export declare function nodesAreEquallySpecific(nodes: Array<string>): boolean;
