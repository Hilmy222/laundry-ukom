import type { Container } from 'postcss';
export declare type walkFunc = (node: Container, opts: {
    noIsPseudoSelector: boolean;
}) => void;
