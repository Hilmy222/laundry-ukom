# admin-resources
Collection of useful resources to build admin template
