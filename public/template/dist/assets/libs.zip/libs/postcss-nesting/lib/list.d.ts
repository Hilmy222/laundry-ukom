export declare function comma(string: string): string[];
