import type { ChildNode, Container } from 'postcss';
export default function cleanupParent(parent: Container<ChildNode>): void;
