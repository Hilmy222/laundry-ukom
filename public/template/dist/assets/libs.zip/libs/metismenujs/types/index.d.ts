import MetisMenu from "./metismenujs.js";
export { MetisMenu };
export default MetisMenu;
//# sourceMappingURL=index.d.ts.map